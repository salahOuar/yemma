import { Routes } from '@angular/router';

export const routes: Routes = [
  {
    path: '',
    redirectTo: 'inbox',
    pathMatch: 'full'
  },
  {
    path: 'inbox',
    loadComponent: () => import('./features/messages/pages/message-list/message-list.component').then(m => m.MessageListComponent)
  },
  {
    path: '**',
    redirectTo: 'inbox'
  }
];
