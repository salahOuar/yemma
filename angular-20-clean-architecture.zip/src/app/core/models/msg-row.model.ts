export interface MsgRow {
  status: 'ok'|'warn'|'err'|'waiting';
  direction: 'Incoming'|'Outgoing';
  network: 'SWIFT'|'SWIFT_I'|'SIC'|'SEPA'|'Other';
  type: string;
  extRef: string;
  intRef: string;
  receiver: string;
  sender: string;
  start: Date | string;
  stop: Date | string;
  owner: string;
  subType?: string;
  replayed?: boolean;
  countOnly?: boolean;
  body?: string;
  [key: string]: any;
}

export interface HistoryItem {
  when: string | Date;
  who: string;
  action: string;
}
