import { Component, output } from '@angular/core';
import { MatMenuModule } from '@angular/material/menu';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  selector: 'app-export-menu',
  standalone: true,
  imports: [MatMenuModule, MatButtonModule, MatIconModule],
  template: `
    <button mat-icon-button [matMenuTriggerFor]="menu"><mat-icon>file_download</mat-icon></button>
    <mat-menu #menu="matMenu">
      <button mat-menu-item (click)="select('body')">Body</button>
      <button mat-menu-item (click)="select('header')">Header</button>
    </mat-menu>
  `
})
export class ExportMenuComponent {
  exportSelected = output<string>();
  select(val: string) { this.exportSelected.emit(val); }
}