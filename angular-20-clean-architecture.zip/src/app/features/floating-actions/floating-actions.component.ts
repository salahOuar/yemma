import { Component, input, output, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MsgRow } from '../../core/models/msg-row.model';
import { ActionButtonComponent } from '../../shared/ui/action-button/action-button.component';
import { ExportMenuComponent } from './components/export-menu/export-menu.component';
import { slideInOutAnimation } from './floating-actions.animations';

@Component({
  selector: 'app-floating-actions',
  standalone: true,
  changeDetection: ChangeDetectionStrategy.OnPush,
  imports: [CommonModule, ActionButtonComponent, ExportMenuComponent],
  animations: [slideInOutAnimation],
  templateUrl: './floating-actions.component.html',
  styleUrls: ['./floating-actions.component.css']
})
export class FloatingActionsComponent {
  row = input<MsgRow | null>(null);
  closeEvent = output<void>({ alias: 'close' });

  onEdit() { alert('Edit ' + this.row()?.extRef); }
  onReplay() { alert('Replay ' + this.row()?.extRef); }
  onExport(type: string) { alert('Export ' + type); }
  onClose() { this.closeEvent.emit(); }
}