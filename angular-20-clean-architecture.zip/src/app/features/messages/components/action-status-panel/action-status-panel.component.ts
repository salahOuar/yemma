import { Component, signal } from '@angular/core';
import { IStatusPanelAngularComp } from 'ag-grid-angular';
import { IStatusPanelParams } from 'ag-grid-community';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-action-status-panel',
  standalone: true,
  imports: [CommonModule],
  template: `
    @if (visible()) {
      <div class="action-panel">
        <span class="info-text">
          <strong>{{ selectedCount() }}</strong> ligne(s) sélectionnée(s)
        </span>
        <div class="btn-group">
          <button (click)="onEdit()" class="action-btn" title="Éditer">Éditer</button>
          <button (click)="onDelete()" class="action-btn delete" title="Supprimer">Supprimer</button>
        </div>
      </div>
    }
  `,
  styles: [`
    .action-panel { display: flex; align-items: center; gap: 15px; padding: 0 10px; }
    .info-text { margin-right: 10px; font-size: 0.9rem; }
    .action-btn { 
      cursor: pointer; padding: 4px 8px; border: 1px solid #ccc; background: white; border-radius: 4px;
    }
    .action-btn:hover { background: #f0f0f0; }
    .action-btn.delete { color: red; border-color: #ffcccc; }
  `]
})
export class ActionStatusPanelComponent implements IStatusPanelAngularComp {
  params!: IStatusPanelParams;
  visible = signal(false);
  selectedCount = signal(0);

  agInit(params: IStatusPanelParams): void {
    this.params = params;
    
    // Écouter les événements de sélection de la grille
    params.api.addEventListener('selectionChanged', () => {
      const count = params.api.getSelectedRows().length;
      this.selectedCount.set(count);
      this.visible.set(count > 0);
    });
  }

  refresh(): boolean { return true; }

  onEdit() { alert('Edit trigger from status panel'); }
  onDelete() { alert('Delete trigger from status panel'); }
}
