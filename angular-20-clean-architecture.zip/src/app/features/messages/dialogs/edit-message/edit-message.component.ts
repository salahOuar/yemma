import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MsgRow } from '../../../../core/models/msg-row.model';

@Component({
  selector: 'app-edit-message-dialog',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, MatDialogModule,
    MatFormFieldModule, MatInputModule, MatSelectModule, MatButtonModule, MatIconModule
  ],
  template: `
    <div class="dialog-header">
      <h2>Edit message</h2>
      <button mat-icon-button (click)="onCancel()"><mat-icon>close</mat-icon></button>
    </div>
    
    <div mat-dialog-content>
      <form [formGroup]="form" class="form-grid">
        <mat-form-field appearance="outline">
          <mat-label>Ext. Ref</mat-label>
          <input matInput formControlName="extRef">
        </mat-form-field>
        <mat-form-field appearance="outline">
          <mat-label>Status</mat-label>
          <mat-select formControlName="status">
            <mat-option value="ok">OK</mat-option>
            <mat-option value="err">Error</mat-option>
          </mat-select>
        </mat-form-field>
      </form>
    </div>

    <div mat-dialog-actions align="end">
      <button mat-button (click)="onCancel()">Cancel</button>
      <button mat-flat-button color="primary" (click)="onSave()">Save</button>
    </div>
  `,
  styles: [`
    .dialog-header { display: flex; justify-content: space-between; align-items: center; padding: 0 24px; }
    .form-grid { display: flex; flex-direction: column; gap: 16px; padding-top: 16px; min-width: 400px; }
  `]
})
export class EditMessageDialogComponent {
  private fb = inject(FormBuilder);
  private dialogRef = inject(MatDialogRef<EditMessageDialogComponent>);
  public data = inject<MsgRow>(MAT_DIALOG_DATA);

  form = this.fb.group({
    extRef: [this.data.extRef || ''],
    status: [this.data.status || 'ok'],
    intRef: [this.data.intRef || '']
  });

  onCancel() { this.dialogRef.close(); }
  onSave() { this.dialogRef.close(this.form.value); }
}
