import { Component, signal, viewChild, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormBuilder } from '@angular/forms';

// Material
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatCardModule } from '@angular/material/card';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatDialog } from '@angular/material/dialog';

// AG Grid
import { AgGridAngular } from 'ag-grid-angular';
import { ColDef } from 'ag-grid-community';

// Custom Components & Core
import { SideDetailComponent } from '../../../side-detail/side-detail.component';
import { FloatingActionsComponent } from '../../../floating-actions/floating-actions.component';
import { ActionStatusPanelComponent } from '../../components/action-status-panel/action-status-panel.component';
import { DirectionCellComponent } from '../../../../shared/ui/direction-cell/direction-cell.component';
import { EditMessageDialogComponent } from '../../dialogs/edit-message/edit-message.component';
import { MsgRow } from '../../../../core/models/msg-row.model';
import { generateRows } from '../../../../core/utils/mock-data.utils';

@Component({
  selector: 'app-message-list',
  standalone: true,
  imports: [
    CommonModule, ReactiveFormsModule, AgGridAngular,
    MatToolbarModule, MatCardModule, MatFormFieldModule, MatInputModule, 
    MatSelectModule, MatButtonModule, MatIconModule, MatCheckboxModule, MatDatepickerModule,
    // Features
    SideDetailComponent, FloatingActionsComponent
  ],
  templateUrl: './message-list.component.html',
  styleUrls: ['./message-list.component.scss']
})
export class MessageListComponent implements OnInit {
  // Services
  private fb = inject(FormBuilder);
  private dialog = inject(MatDialog);

  // State Signals
  rowData = signal<MsgRow[]>([]);
  selectedRow = signal<MsgRow | null>(null);
  
  // ViewChilds
  grid = viewChild(AgGridAngular);

  // Form
  form = this.fb.group({
    direction: ['Incoming'],
    network: ['SWIFT'],
    start: [new Date()],
    stop: [new Date()]
  });

  // AG Grid Config
  components = { actionStatusPanel: ActionStatusPanelComponent };
  statusBar = {
    statusPanels: [
      { statusPanel: 'actionStatusPanel', align: 'center' },
      { statusPanel: 'agTotalAndFilteredRowCountComponent', align: 'left' }
    ]
  };

  columnDefs: ColDef<MsgRow>[] = [
    { field: 'status', width: 100, pinned: 'left', cellRenderer: (p: any) => this.statusRenderer(p.value) },
    { 
      field: 'direction', 
      width: 140, 
      cellRenderer: DirectionCellComponent, // Utilisation directe du composant autonome
      cellRendererParams: {
        // Callback si besoin
      }
    },
    { field: 'network' },
    { field: 'type' },
    { field: 'extRef', minWidth: 200 },
    { field: 'receiver' },
    { field: 'sender' }
  ];

  ngOnInit() {
    this.rowData.set(generateRows(100));
  }

  // Helpers
  statusRenderer(status: string) {
    const colors: any = { ok: 'green', err: 'red', warn: 'orange', waiting: 'grey' };
    return `<span style="color: ${colors[status] || 'black'}; font-weight: bold">${status}</span>`;
  }

  // Events
  onRowSelected(event: any) {
    const selected = event.api.getSelectedRows()[0];
    this.selectedRow.set(selected || null);
  }

  onSideClose() {
    this.selectedRow.set(null);
    this.grid()?.api.deselectAll();
  }

  onSideNavigate(dir: 'previous' | 'next') {
    // Logique de navigation simplifiée pour l'exemple
    console.log('Navigating', dir);
  }
}
