import { Component, input, output, computed, signal, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatTabsModule } from '@angular/material/tabs';
import { MsgRow, HistoryItem } from '../../core/models/msg-row.model';

@Component({
  selector: 'app-side-detail',
  standalone: true,
  imports: [CommonModule, MatTabsModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './side-detail.component.html',
  styleUrls: ['./side-detail.component.css']
})
export class SideDetailComponent {
  // Inputs / Outputs
  row = input<MsgRow | null>(null); // Signal Input
  close = output<void>();
  navigate = output<'previous' | 'next'>();

  // Computed State
  isOpen = computed(() => !!this.row());
  
  history = computed(() => {
    const r = this.row();
    if (!r) return [];
    // Mock history generation based on row
    const base = r.extRef || 'MSG';
    return [
      { when: '2025-10-16 09:12', who: 'system', action: `Imported ${base}` },
      { when: '2025-10-16 09:14', who: 'NDP', action: `Routed to ${r.receiver}` },
      { when: '2025-10-16 09:18', who: 'ops', action: 'Validated headers' },
      { when: '2025-10-16 09:20', who: 'ops', action: 'Delivered to back-office' },
    ] as HistoryItem[];
  });

  onClose() {
    this.close.emit();
  }

  onPrev() {
    this.navigate.emit('previous');
  }

  onNext() {
    this.navigate.emit('next');
  }
}
