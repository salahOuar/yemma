import { Component, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { MatSidenavModule } from '@angular/material/sidenav';
import { MatToolbarModule } from '@angular/material/toolbar';
import { MatListModule } from '@angular/material/list';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

@Component({
  selector: 'app-main-layout',
  standalone: true,
  imports: [CommonModule, RouterModule, MatSidenavModule, MatToolbarModule, MatListModule, MatIconModule, MatButtonModule],
  template: `
    <mat-sidenav-container class="h-screen">
      <mat-sidenav #sidenav mode="side" opened [class.w-64]="!collapsed()" [class.w-16]="collapsed()">
        <mat-toolbar color="primary">
          <mat-icon>inbox</mat-icon>
          @if (!collapsed()) { <span class="ml-2">Messages</span> }
        </mat-toolbar>
        
        <mat-nav-list>
          <a mat-list-item routerLink="/inbox" routerLinkActive="active">
            <mat-icon matListItemIcon>inbox</mat-icon>
            @if (!collapsed()) { <span matListItemTitle>Inbox</span> }
          </a>
        </mat-nav-list>
      </mat-sidenav>

      <mat-sidenav-content>
        <mat-toolbar>
          <button mat-icon-button (click)="toggleCollapse()">
            <mat-icon>menu</mat-icon>
          </button>
          <span>Console</span>
        </mat-toolbar>
        
        <router-outlet></router-outlet>
      </mat-sidenav-content>
    </mat-sidenav-container>
  `,
  styles: [`
    .h-screen { height: 100vh; }
    .w-64 { width: 250px; }
    .w-16 { width: 60px; }
    mat-sidenav { transition: width 0.2s; border-right: 1px solid #eee; }
  `]
})
export class MainLayoutComponent {
  collapsed = signal(false);
  toggleCollapse() { this.collapsed.update(v => !v); }
}
