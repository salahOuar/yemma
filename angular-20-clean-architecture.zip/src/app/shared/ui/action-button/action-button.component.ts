import { Component, input, output } from '@angular/core';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-action-button',
  standalone: true,
  imports: [MatButtonModule, MatIconModule, MatTooltipModule],
  template: `
    <button mat-icon-button (click)="action.emit()" [matTooltip]="tooltip() || ''" [class.is-close]="isCloseBtn()">
      <mat-icon>{{ icon() }}</mat-icon>
    </button>
  `,
  styles: ['.is-close { color: #aaa; } .is-close:hover { color: white; }']
})
export class ActionButtonComponent {
  icon = input.required<string>();
  tooltip = input<string>();
  isCloseBtn = input(false);
  action = output<void>();
}