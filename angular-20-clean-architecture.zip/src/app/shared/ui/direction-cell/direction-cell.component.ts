import { Component, input, output, ChangeDetectionStrategy } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';

@Component({
    selector: 'app-direction-cell',
    standalone: true,
    imports: [MatIconModule],
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
    <div class="dir-cell">
      <span class="dir-label">{{ value() }}</span>
      <span class="row-actions">
        <mat-icon class="action-icon" (click)="onMenuClick($event)">more_vert</mat-icon>
        <mat-icon class="action-icon">edit</mat-icon>
      </span>
    </div>
    `,
    styles: [`
      .dir-cell {
        display: flex;
        align-items: center;
        justify-content: space-between;
        width: 100%;
        height: 100%;
        padding-right: 8px;
      }
      .dir-label {
        font-weight: 500;
      }
      .row-actions {
        display: flex;
        gap: 4px;
        opacity: 0; /* Caché par défaut */
        transform: translateY(3px);
        transition: opacity 0.2s ease, transform 0.2s ease;
        pointer-events: none;
      }
      /* Affichage au survol */
      .dir-cell:hover .row-actions {
        opacity: 1;
        transform: translateY(0);
        pointer-events: auto;
      }
      .action-icon {
        font-size: 18px;
        width: 18px;
        height: 18px;
        cursor: pointer;
        color: #666;
      }
      .action-icon:hover {
        color: #000;
      }
    `]
})
export class DirectionCellComponent {
  value = input.required<string>();
  menu = output<MouseEvent>();

  onMenuClick(event: MouseEvent) {
    event.stopPropagation();
    this.menu.emit(event);
  }
}
